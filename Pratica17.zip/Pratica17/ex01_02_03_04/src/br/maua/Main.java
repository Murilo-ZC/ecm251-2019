package br.maua;

public class Main {

    public static void main(String[] args) {
        MainApp app = new MainApp();
        app.mainLoop();
    }
}
